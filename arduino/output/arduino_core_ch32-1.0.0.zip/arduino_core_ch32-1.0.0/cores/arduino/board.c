#include "board.h"

#ifdef __cplusplus
extern "C" {
#endif


WEAK void pre_init(void)
{
  hw_config_init();
}


#ifdef __cplusplus
}
#endif
