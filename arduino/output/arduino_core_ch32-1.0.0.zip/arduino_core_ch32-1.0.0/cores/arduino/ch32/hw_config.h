
#ifndef __HW_CONFIG_H
#define __HW_CONFIG_H

#include "ch32_def.h"

#ifdef __cplusplus
extern "C" {
#endif

void hw_config_init(void);

#ifdef __cplusplus
}
#endif

#endif /* __HW_CONFIG_H */


