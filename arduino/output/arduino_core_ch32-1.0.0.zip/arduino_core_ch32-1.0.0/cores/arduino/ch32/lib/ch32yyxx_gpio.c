#ifdef CH32V00x
#include "ch32v00x_gpio.c"
#endif

#ifdef CH32V20x
#include "ch32v20x_gpio.c"
#endif