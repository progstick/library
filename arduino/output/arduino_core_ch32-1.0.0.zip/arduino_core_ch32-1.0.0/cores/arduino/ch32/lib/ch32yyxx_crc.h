#ifndef __CH32YYXX_CRC_H_
#define __CH32YYXX_CRC_H_

#ifdef CH32V20x
#include "ch32v20x_crc.h"
#endif

#endif /* __CH32YYXX_CRC_H_ */