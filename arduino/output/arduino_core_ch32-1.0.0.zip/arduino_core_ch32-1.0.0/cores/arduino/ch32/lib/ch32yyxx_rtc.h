#ifndef __CH32YYXX_CTC_H_
#define __CH32YYXX_CTC_H_ 

#ifdef CH32V20x
#include "ch32v20x_rtc.h"
#endif

#endif  /* __CH32YYXX_CTC_H_ */ 