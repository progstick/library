#ifdef CH32V20x
#include "ch32v20x_crc.c"
#endif