#ifndef __CH32YYXX_DVP_H_
#define __CH32YYXX_DVP_H_

#ifdef CH32V30x
#include "ch32v30x_dvp.h"
#endif

#endif /* __CH32YYXX_DVP_H_ */
