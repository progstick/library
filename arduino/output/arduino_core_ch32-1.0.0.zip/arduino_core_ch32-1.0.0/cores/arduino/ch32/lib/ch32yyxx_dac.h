#ifndef __CH32YYXX_DAC_H_
#define __CH32YYXX_DAC_H_

#ifdef CH32V30x
#include "ch32v30x_dac.h"
#endif

#endif /* __CH32YYXX_DAC_H_ */