#ifndef __CH32YYXX_RNG_H_
#define __CH32YYXX_RNG_H_

#ifdef CH32V30x
#include "ch32v30x_rng.h"
#endif

#endif  /* __CH32YYXX_RNG_H_ */