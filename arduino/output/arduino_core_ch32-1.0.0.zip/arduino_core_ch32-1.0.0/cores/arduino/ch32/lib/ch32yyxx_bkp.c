#ifdef CH32V00x  
//nothing
#elif CH32V10x
#include "ch32v10x_bkp.c"

#elif CH32V20x
#include "ch32v20x_bkp.c"

#elif CH32V30x
#include "ch32v30x_bkp.c"
#endif