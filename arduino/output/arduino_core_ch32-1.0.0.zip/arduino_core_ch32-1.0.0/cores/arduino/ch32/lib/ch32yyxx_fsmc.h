#ifndef __CH32YYXX_FSMC_H_
#define __CH32YYXX_FSMC_H_

#ifdef CH32V30x
#include "ch32v30x_fsmc.h"
#endif

#endif /* __CH32YYXX_FSMC_H_ */