#ifdef CH32V00x
#include "system_ch32v00x.c"    
#endif


#ifdef CH32V20x
#include "system_ch32v20x.c"    
#endif

