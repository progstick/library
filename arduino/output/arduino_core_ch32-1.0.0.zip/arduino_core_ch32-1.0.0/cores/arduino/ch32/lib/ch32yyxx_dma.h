#ifndef __CH32YYXX_DMA_H__
#define __CH32YYXX_DMA_H__

#ifdef CH32V00x
#include "ch32v00x_dma.h"
#endif

#ifdef CH32V20x
#include "ch32v20x_dma.h"
#endif

#endif /* __CH32YYXX_DMA_H__ */